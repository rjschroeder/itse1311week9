//alert("Hello");

console.log("Hello web programming");
