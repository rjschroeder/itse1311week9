//alert("Hello");

console.log("Hello chapter 2");
