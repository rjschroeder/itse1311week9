console.clear();

try {
  let myFirstNumber = 0;
  let mySecondNumber = 2;

  if (myFirstNumber === 0) {
    console.log("This is 0");
    paymentReceived;
    throw "Throwing this is zero";
  } else if (mySecondNumber === 2) {
    console.log("This is a 2");
  } else if (myFirstNumber === 0 || mySecondNumber === 2) {
    console.log("Either a number was 0 or 2");
  } else if (myFirstNumber === 3 && mySecondNumber !== 7) {
    console.log("Both numbers were 0 and 7");
    alert("Payment received");
  } else {
    console.log("Not any of the numbers");
  }
} catch (error) {
  //end try and catch exception
  //console.log("Caught error");
  /////////////////////////////
  //console.error(error.name);
  //console.error(error.message);
  //console.error(error.stack);
  console.warn("Warning, check line x");
  console.error(error.stack);
} finally {
  console.log("Thank you for visiting");
}
