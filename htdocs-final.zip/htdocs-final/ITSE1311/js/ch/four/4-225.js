console.clear();

document.write("Hello Error");

/*
Types of errors and strategies

bug
syntax errors - unrecognized code
run-time error - unexecutable code, like a non-existent function
logic error - when undesired out is delivered
tracing error with window.alert
commenting out
isolating code 
breakpoints
handling exceptions and errors, bullet proofing
try, throw, catch, finally

*/

//let if = "Rowen Schroeder"; //is a syntax error because "if" is reserved

//console.log(if);
