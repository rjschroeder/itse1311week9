var fName = document.getElementById("firstName");

//var fName = "Rowen Schroeder 4";

/*
let myNumber = 2;

if (myNumber === 2) {
    let fName = "Rowen Schroeder 4";
    console.log(fName);
}
*/

function chckName() {
  document.write("<p>Rowen</p>");
}
