<?php

session_start();

/*For test purposes. Do not use in real scenario
$first_name = $_GET['first_name'];
$last_name = $_GET['last_name'];
*/

$first_name = $_SESSION['first_name'];
$last_name = $_SESSION['last_name'];

echo "Hello " . $first_name . " " . $last_name . "<br />";

echo "Welcome back!";
echo "<br /><br />";

echo "<a href='logout.php'>Log Out!</a>";

?>