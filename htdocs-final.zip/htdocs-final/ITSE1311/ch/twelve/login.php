<style>
    p {
        font-size: 15px;
        font-family: verdana;
    }

</style>


<?php

if (($_SERVER['REQUEST_METHOD']) == 'POST') {

    require_once("connection.php");

    //require_once("guid.php");


    $email = $conn->real_escape_string($_POST['your_email']);
    $password = $conn->real_escape_string($_POST['password']);

    //require_once("insert.php");

    /*
    $message = "<p><strong>Email</strong>: " . $email . "</p>";
    $message .= "<p><strong>Password</strong>: " . $password . "</p>";

    //$message .= "<p><strong>Form ID</strong>: " . $form_id . "</p>";

    echo $message;

    */

    require_once("login-select.php");

    if(isset($_SESSION['email'])) {
        echo "I'm logged in";
        //exit;
    } else {
        echo "I'm not logged in";
        //exit;
    }

    //echo "Your name is " . $myName;
} else {
    //echo "<a href='login.html' target='_blank'>Please submit a form</a>";
    //header('Location: login.html');

    require_once("login-form.php");

    exit;
}

?>