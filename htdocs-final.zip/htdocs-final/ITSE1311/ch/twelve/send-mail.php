<?php
/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); 
*/

//use PHPMailer\PHPMailer\PHPMailer;
//use PHPMailer\PHPMailer\Exception;

	require 'PHPMailer-master/src/Exception.php';
  	require_once("PHPMailer-master/src/PHPMailer.php");
  	require_once("PHPMailer-master/src/SMTP.php");

$subject = "Your confirmation for volunteer";
//$to = "nimbik.6@gmail.com"; //customer
$bcc = "itse1311.testing.rowens@outlook.com";
//$message = "Message sent from vscode";

    //include("../_settings/phpmailer.php");

    $mail = new PHPMailer\PHPMailer\PHPMailer();
    $mail->IsSMTP(); // enable SMTP
    $mail->CharSet = "UTF-8";
    $mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only // Activate this to show dev messages
    $mail->SMTPAuth = "true"; // authentication enabled // change to false for non authentication use
    $mail->SMTPSecure = 'tls'; // secure transfer enabled REQUIRED for Gmail
    $mail->Host = "smtp-mail.outlook.com";
    //$mail->Host = "smtp.office365.com";
    $mail->Port = 587; // or 587 // use 25 for non credentialed
    $mail->IsHTML(true);
    $mail->Username = $bcc;
    $mail->Password = "userpassword123";
    $mail->SetFrom($bcc);
    $mail->Subject = $subject;
    $mail->Body = $message  ;
    $mail->AddAddress($email); // notification to submitter
    $mail->addBCC($bcc); // notification to submitter

    $mail->AddAttachment("uploads/".$form_id.$file_name);



     if(!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
     } else {
        echo "Message has been sent";
     }


?>