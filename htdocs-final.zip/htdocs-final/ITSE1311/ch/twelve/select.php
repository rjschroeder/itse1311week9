<table border="1">
    <tr>
        <th>FIRST NAME</th>
        <th>LAST NAME</th>
        <th>EMAIL</th>
    </tr>
<?php

require_once("connection.php");

//check connection

if(mysqli_connect_errno()) {

    //printf("Connection failed %\n", mysqli_connect_error());
    echo "See line 9";
    //exit();
}

//$first_name = 'Rowen';
$first_name = $_GET['first_name'];
$first_name = $conn->real_escape_string($first_name);

//echo $first_name;
//exit;

$i = 0;

$query = "SELECT first_name,last_name,customer_email FROM `tbl_contacts` WHERE first_name = '$first_name' ORDER BY first_name DESC";

if ($stmt = $conn->prepare($query)){
    $stmt->execute();
    $stmt->bind_result($first_name, $last_name, $customer_email);

    while($stmt->fetch()) {
        $i++;
        //echo " Selection worked";
        echo "<tr>";
        echo "<td>" . $first_name . "</td>";
        echo "<td>" . $last_name . "</td>";
        echo "<td>" . $customer_email . "</td>";
        echo "</tr>";
    }

}


//echo "Number of rows " . $i;

if ($i == 0) {
    echo "<tr>";
    echo "<td colspan='3'>Sorry, database does not exist.</td>";
    echo "</tr>";
}

?>

</table>