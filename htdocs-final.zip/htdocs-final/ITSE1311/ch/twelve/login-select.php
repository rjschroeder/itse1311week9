<?php

session_start();

if (($_SERVER['REQUEST_METHOD']) == 'POST') {

    require_once("connection.php");

    //check connection

    if(mysqli_connect_errno()) {

        //printf("Connection failed %\n", mysqli_connect_error());
        echo "See line 9";
        //exit();
    }

    /* For testing purposes
    $user_email = 'rowen.schroeder@email.com';
    $user_password = 'userpassword123';
    */

    $user_email = $_POST['your_email'];
    $user_password = $_POST['password'];


    $i = 0;

    $query = "SELECT user_email, user_password, first_name, last_name FROM `tbl_accounts` WHERE user_email = '$user_email' AND user_password = '$user_password' LIMIT 1";

    if ($stmt = $conn->prepare($query)){
        $stmt->execute();
        $stmt->bind_result($user_email, $user_password, $first_name, $last_name);

        while($stmt->fetch()) {
            $i++;
            //echo " Selection worked";
            //echo "USERNAME: " . $user_email . "<br />";
            //echo "PASSWORD: " . $user_password . "<br />";

            $_SESSION['email'] = $email;
            $_SESSION['first_name'] = $first_name;
            $_SESSION['last_name'] = $last_name;

            echo "<strong>Hello " . $first_name . "</strong>";
            echo "<p>Welcome to my site</p>";
            //echo "<a href='your-profile.php?first_name={$first_name}&last_name={$last_name}'>Go to your profile</a>";
            echo "<a href='your-profile.php'>Go to your profile</a>";
        }

    }


    //echo "Number of rows " . $i;

    if ($i == 0) {
        echo "Sorry, record does not exist.";
    }

} else {
    echo "<a href='login.html' target='_blank'>Please submit a form</a>";
    header('Location: login.html');
    exit;
}

?>