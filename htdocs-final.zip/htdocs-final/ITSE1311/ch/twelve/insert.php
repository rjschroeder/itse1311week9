<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once("connection.php");

    //disable autocommit
    $conn->autocommit(FALSE);

    try {

    /*
        $myName = $_POST['full_name'];
        $age = $_POST['age'];
        $email = $_POST['your_email'];
        $phone = $_POST['phone'];
        $url = $_POST['url'];
        $start_date = $_POST['start_date'];
        $t_shirt = $_POST['t_shirt'];
        $custom = $_POST['custom'];
        $color = $_POST['color'];
        $file = $_POST['file'];
        $participation = $_POST['participation'];
        $time_of_day = $_POST['time_of_day'];
        $about_you = $_POST['about_you'];
        $terms = $_POST['terms'];
    */

        //tbl_contacts
        $sqlContacts = "INSERT INTO `tbl_contacts` 
        (
            `record_id`, 
            `first_name`, 
            `last_name`, 
            `customer_email`, 
            `phone`, 
            `age`,
            `date_inserted`, 
            `date_updated`, 
            `guid`
        ) 
        VALUES 
        (
            NULL, 
            '$first_name', 
            '$last_name', 
            '$email', 
            '$phone', 
            '$age',
            current_timestamp(), 
            current_timestamp(), 
            '$form_id'
        );";

        if($conn->query($sqlContacts) === TRUE) {
            echo "Record Inserted";
        } else {
            echo "Error Inserting: " . mysqli_error($conn);
            throw new Exception("Error on line 58");
        }

        $last_id = $conn->insert_id;
        $all_time_of_day_total_db = str_replace("<br />", ",", $all_time_of_day_total);

        //tbl_preferences
        
        $sql = "INSERT INTO `tbl_preferences` 
        (
            `record_id`, 
            `info_record_id`,
            `url`,
            `start_date`,
            `t_shirt`,
            `custom`,
            `color`,
            `file`,
            `participation`,
            `time_of_day`,
            `about_you`,
            `terms`,
            `date_inserted`, 
            `date_updated`, 
            `guid`
        ) 
        VALUES 
        (
            NULL, 
            '$last_id',
            '$url', 
            '$start_date',
            '$t_shirt',
            '$custom',
            '$color', 
            '$form_id.$file_name',
            '$participation', 
            '$all_time_of_day_total_db',
            '$about_you',
            '$terms',
            current_timestamp(), 
            current_timestamp(), 
            '$form_id'
        );";


        if($conn->query($sql) === TRUE) {
            echo "Record Inserted";
        } else {
            echo "Error Inserting: " . mysqli_error($conn);
            throw new Exception("Error on line 107");
        }


        //no errors
        $conn->commit();
    } catch  (Exception $e) {
        //if error, cancel transaction
        $conn->rollback();
        echo$e->getMessage();
    }

    $conn->close();

} else {
    echo "<a href='form.html' target='_blank'>Please submit a form</a>";
    header('Location: form.html');
    exit;
}
?>