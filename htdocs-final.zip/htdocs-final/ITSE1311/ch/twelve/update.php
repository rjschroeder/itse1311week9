<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    require_once("connection.php");

    $myName = $_POST['full_name'];
    $age = $_POST['age'];
    $email = $_POST['your_email'];
    $phone = $_POST['phone'];


    $sql = "UPDATE `itse1311_table` SET `first_name` = 'amyupdatedtwice' WHERE `itse1311_table`.`record_id` = 9;";

    if($conn->query($sql) === TRUE) {
        echo "Record Updated";
    } else {
        echo "Error Updating";
    }

    $conn->close();
} else {
    echo "<a href='form.html' target='_blank'>Please submit a form</a>";
    header('Location: form.html');
    exit;
}
?>