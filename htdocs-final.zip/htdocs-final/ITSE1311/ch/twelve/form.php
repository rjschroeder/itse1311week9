<style>
    p {
        font-size: 15px;
        font-family: verdana;
    }

</style>


<?php

if (($_SERVER['REQUEST_METHOD']) == 'POST') {

    require_once("connection.php");

    require_once("guid.php");


    $myName = $conn->real_escape_string($_POST['full_name']);
    $age = $conn->real_escape_string($_POST['age']);
    $email = $conn->real_escape_string($_POST['your_email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $url = $conn->real_escape_string($_POST['url']);
    $start_date = $conn->real_escape_string($_POST['start_date']);
    $t_shirt = $conn->real_escape_string($_POST['t_shirt']);
    $custom = $conn->real_escape_string($_POST['custom']);
    $color = $conn->real_escape_string($_POST['color']);
    $file_name = $conn->real_escape_string($_POST['file']);
    $participation = $conn->real_escape_string($_POST['participation']);
    $time_of_day = $_POST['time_of_day'];
    $about_you = $conn->real_escape_string($_POST['about_you']);
    $terms = $conn->real_escape_string($_POST['terms']);

    if(empty($email)) {
        echo "Email is required";
        exit();
    }

    $fullNamePieces = explode(" ", $myName);

    $first_name = $fullNamePieces[0];
    $last_name = $fullNamePieces[1];

    /*
    full_name
    age
    your_email
    phone
    url
    start_date
    t_shirt
    custom
    color
    file
    participation
    time_of_day
    about_you
    terms
    */

    $i = 0;

    $all_time_of_day_total = '';
    $br = "<br />";

    if (is_array($time_of_day)) {
        foreach($time_of_day AS $all_time_of_day) {
            $i++;
            //echo "Is an array" . $i . "<br />";
            //echo $all_time_of_day . "<br />";

            $all_time_of_day_total = $all_time_of_day . $br . $all_time_of_day_total;

        }
    } else {
        echo "Not an array";
    }

    require_once('upload.php');

    require_once("insert.php");


    $message = "<p><strong>Full Name</strong>: " . $myName . "</p>";
    $message .= "<p><strong>Age</strong>: " . $age . "</p>";
    $message .= "<p><strong>Email</strong>: " . $email . "</p>";
    $message .= "<p><strong>Phone</strong>: " . $phone . "</p>";
    $message .= "<p><strong>Social Media URL</strong>: " . $url . "</p>";
    $message .= "<p><strong>Start Date</strong>: " . $start_date . "</p>";
    $message .= "<p><strong>T-shirt Size</strong>: " . $t_shirt . "</p>";
    $message .= "<p><strong>Custom Size</strong>: " . $custom . "</p>";
    $message .= "<p><strong>T-shirt Color</strong>: " . $color . "</p>";
    $message .= "<p><strong>Required Documents</strong>: " . $file . "</p>";
    $message .= "<p><strong>Participating In</strong>: " . $participation . "</p>";
    $message .= "<p><strong>Time of Day</strong><br />" . $all_time_of_day_total . "</p>";
    $message .= "<p><strong>About You</strong>: " . $about_you . "</p>";
    $message .= "<p><strong>Terms and Conditions</strong>: " . $terms . "</p>";

    $message .= "<p><strong>Form ID</strong>: " . $form_id . "</p>";

    echo $message;

    require_once("send-mail.php");

    //echo "Your name is " . $myName;
} else {
    echo "<a href='form.html' target='_blank'>Please submit a form</a>";
    header('Location: form.html');
    exit;
}

?>