<?php

$password = sha2('userpassword123');

echo $password;
?>