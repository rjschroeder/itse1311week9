<?php

require_once("../connection.php");


$sql = "INSERT INTO `itse1311_table` 
(
    `record_id`, 
    `first_name`, 
    `last_name`, 
    `customer_email`, 
    `phone`, 
    `date_inserted`, 
    `date_updated`, 
    `guid`
) 
VALUES 
(
    NULL, 
    'amy', 
    'scott',
    'amys@example.com', 
    '555-553-7755', 
    current_timestamp(), 
    current_timestamp(), 
    NULL
);";

if($conn->query($sql) === TRUE) {
    echo "Record Inserted";
} else {
    echo "Error Inserting";
}

?>