<?php

require_once("connection.php");

echo "test";

?>