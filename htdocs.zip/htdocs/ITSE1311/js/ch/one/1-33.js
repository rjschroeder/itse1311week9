function chckName() {
    document.write("<p>Rowen</p>");
}