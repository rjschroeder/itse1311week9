<?php


ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);
error_reporting(E_ALL);


$rightNow = date("n/j/Y G:i");

//echo $rightNow;

$localhost = "bG9jYWxob3N0";
$username = "aXRzZTEzMTFhZG1pbg==";
//$username = "aHRtbF91c2Vy";
$password = "YWJjMTIzNDU2IQ==";

$conn = new mysqli(base64_decode($localhost), base64_decode($username), base64_decode($password), "itse1311");

//Create connection
if($conn->connect_error) {
    die("Connection Failed" . $conn->connect_error);
} else {
    //echo "Connection Successful";
}


?>