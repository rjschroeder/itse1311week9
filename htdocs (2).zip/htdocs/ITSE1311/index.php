<?php

$myVar = "Rowen Schroeder";

if ($myVar == "Rowen Schroeder") {
    echo $myVar;
}

echo $myVar;

?>