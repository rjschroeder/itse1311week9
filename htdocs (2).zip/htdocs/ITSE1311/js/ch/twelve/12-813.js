$(document).ready(function () {
  console.log("Ready!");
});

$(document).on("click", "#btn", makeRed);

function makeRed() {
  $("#myDiv3").css("color", "red");
}
