//////////// DataTypes /////////////
// number = positive or negative
// boolean = true or false
// string = any text such as "Hello World"
// undefined = unassigned, undeclared, nonexistent
//null = any empty value

var myNumber = 46;

var myStatus = false;

var myName = "Rowen Schroeder";

var myUndefined;

var myNull;

console.log(myUndefined); //this outputs undefined
console.log(myNull);

function chckName() {
  document.write("<p>Rowen</p>");
}
