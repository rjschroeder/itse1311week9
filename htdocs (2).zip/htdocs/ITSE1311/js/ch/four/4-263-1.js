console.clear();

let myFirstNumber = 3;
let mySecondNumber = 7;

if (myFirstNumber === 4) {
  console.log("This is 0");
} else if (mySecondNumber === 5) {
  console.log("This is a 2");
} else if (myFirstNumber === 0 || mySecondNumber === 2) {
  console.log("Either a number was 0 or 2");
} else if (myFirstNumber === 0 && mySecondNumber === 7) {
  console.log("Both numbers were 0 and 7");
  alert("Payment received");
} else {
  console.log("Not any of the numbers");
}
